package com.team.springboot.dao;

import org.springframework.data.repository.CrudRepository;

import com.team.springboot.model.Employee;

public interface EmployeeDao extends CrudRepository<Employee, Integer> {
	
}