package com.team.springboot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.team.springboot.dao.EmployeeDao;
import com.team.springboot.model.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeDao empDao;
	
	
	public List<Employee> getAllEmployee(){
		List<Employee> listEmp = new ArrayList<Employee>();
		empDao.findAll().forEach(action -> listEmp.add(action));
		return listEmp;
		
		
	}

}
